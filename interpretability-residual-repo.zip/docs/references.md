# References

Bricken, T., Templeton, A., Batson, J., et al. (2023). Towards monosemanticity: Decomposing language models with dictionary learning. *Transformer Circuits Thread*.

Conmy, A., Mavor-Parker, A. N., Lynch, A., Heimersheim, S., & Garriga-Alonso, A. (2023). Towards automated circuit discovery for mechanistic interpretability. arXiv:2304.14997.

Elhage, N., Nanda, N., Olsson, C., et al. (2021). A mathematical framework for transformer circuits. *Transformer Circuits Thread*.

Lieberum, T., Rahtz, M., Kramar, J., Irving, G., Shah, R., & Mikulik, V. (2023). Does circuit analysis interpretability scale? Evidence from multiple choice capabilities in Chinchilla.

Lin, Z., & Liu, F. (2026). Position: Mechanistic interpretability must disclose identification assumptions for causal claims. arXiv:2605.08012.

Marks, S., Rager, C., Michaud, E. J., Belinkov, Y., Bau, D., & Mueller, A. (2024). Sparse feature circuits: Discovering and editing interpretable causal graphs in language models.

Miller, J., Chughtai, B., & Saunders, W. (2024). Transformer circuit faithfulness metrics are not robust. *COLM 2024*. arXiv:2407.08734.

Mueller, A., Geiger, A., Wiegreffe, S., et al. (2025). MIB: A mechanistic interpretability benchmark. *ICML 2025*.

Penrose, R. (1989). *The emperor's new mind*. Oxford University Press.

Wang, K., Variengien, A., Conmy, A., Shlegeris, B., & Steinhardt, J. (2023). Interpretability in the wild: A circuit for indirect object identification in GPT-2 small. *ICLR 2023*. arXiv:2211.00593.

Zhang, F., & Nanda, N. (2024). Towards best practices of activation patching in language models. *ICLR 2024*. arXiv:2309.16042.

---
Note: arXiv identifiers for Lieberum et al. and Marks et al., and the full author lists for Conmy et al. and Bricken et al., should be verified against the arXiv listing before formal citation.
