"""
Decision model: is it worth funding an experiment to measure the
'unmappable residual' in AI reasoning?

v2: parameters are DISTRIBUTIONS, not point estimates, because
completeness metrics are known to be method-sensitive.
"""
import numpy as np
rng = np.random.default_rng(7)
N = 200_000

# ---- Parameters as distributions (all illustrative) ----
# Prior credence a persistent residual (ceiling) is real.
p_ceiling = rng.beta(2, 8, N)          # mean ~0.20, wide

# Safety value lost if ceiling is real and field over-trusts interp.
cost_ignored = rng.beta(6, 14, N)      # mean ~0.30

# Cost of hedging away from interp when ceiling is NOT real.
cost_hedge = rng.beta(2, 38, N)        # mean ~0.05

# Experiment informativeness. Metric noise (ablation-method sensitivity,
# benchmark choice) degrades this -- modelled explicitly.
tpr = rng.beta(14, 6, N)               # mean ~0.70
fpr = rng.beta(5, 15, N)               # mean ~0.25

exp_cost = rng.beta(2, 98, N)          # mean ~0.02

def loss_best(p, ci, ch):
    return np.minimum(p*ci, (1-p)*ch)

# Loss with no experiment: default is to keep trusting interp
loss_none = p_ceiling * cost_ignored

# Loss with experiment
p_sig = tpr*p_ceiling + fpr*(1-p_ceiling)
p_nosig = 1 - p_sig
post_sig  = (tpr*p_ceiling)/p_sig
post_nos  = ((1-tpr)*p_ceiling)/p_nosig
loss_exp = (p_sig*loss_best(post_sig, cost_ignored, cost_hedge)
          + p_nosig*loss_best(post_nos, cost_ignored, cost_hedge)
          + exp_cost)

voi = loss_none - loss_exp

print(f"Mean VoI            : {voi.mean():+.4f}")
print(f"Median VoI          : {np.median(voi):+.4f}")
print(f"P(VoI > 0)          : {(voi>0).mean():.3f}")
print(f"90% interval        : [{np.percentile(voi,5):+.4f}, {np.percentile(voi,95):+.4f}]")

# ---- Break-even prior, holding other params at their means ----
ci, ch, t, f, ec = cost_ignored.mean(), cost_hedge.mean(), tpr.mean(), fpr.mean(), exp_cost.mean()
def voi_at(pr):
    ln = pr*ci
    ps = t*pr + f*(1-pr); pn = 1-ps
    po = (t*pr)/ps; pnn = ((1-t)*pr)/pn
    le = ps*min(po*ci,(1-po)*ch) + pn*min(pnn*ci,(1-pnn)*ch) + ec
    return ln-le
lo, hi = 0.001, 0.9
for _ in range(80):
    mid=(lo+hi)/2
    if voi_at(mid) < 0: lo=mid
    else: hi=mid
print(f"\nBreak-even prior    : {(lo+hi)/2:.3f}")

# ---- How much does METRIC NOISE matter? ----
# Degrade the experiment's discriminating power and see when VoI dies.
print("\nEffect of metric noise on the experiment's value:")
print("(gap = tpr - fpr, i.e. how well the study separates the hypotheses)")
for gap in [0.60, 0.45, 0.30, 0.20, 0.10, 0.05]:
    t2 = 0.5 + gap/2; f2 = 0.5 - gap/2
    pr = 0.20
    ln = pr*ci
    ps = t2*pr + f2*(1-pr); pn = 1-ps
    po = (t2*pr)/ps; pnn = ((1-t2)*pr)/pn
    le = ps*min(po*ci,(1-po)*ch) + pn*min(pnn*ci,(1-pnn)*ch) + ec
    print(f"  gap={gap:.2f} -> VoI={ln-le:+.4f}")
