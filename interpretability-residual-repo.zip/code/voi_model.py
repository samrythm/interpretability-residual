"""Do the thresholds survive different parameterisations?
Reviewer objection: '0.15 and 0.20 are artefacts of your priors.'
Test: re-derive both under different distributional families and means."""
import numpy as np
rng=np.random.default_rng(11)

def breakeven_prior(ci,ch,t,f,ec):
    lo,hi=1e-4,0.95
    def v(pr):
        ln=pr*ci; s=t*pr+f*(1-pr); n=1-s
        a=(t*pr)/s; b=((1-t)*pr)/n
        return ln-(s*min(a*ci,(1-a)*ch)+n*min(b*ci,(1-b)*ch)+ec)
    for _ in range(90):
        m=(lo+hi)/2
        if v(m)<0: lo=m
        else: hi=m
    return (lo+hi)/2

def sep_threshold(pr,ci,ch,ec):
    lo,hi=0.001,0.99
    def v(g):
        t,f=.5+g/2,.5-g/2
        ln=pr*ci; s=t*pr+f*(1-pr); n=1-s
        a=(t*pr)/s; b=((1-t)*pr)/n
        return ln-(s*min(a*ci,(1-a)*ch)+n*min(b*ci,(1-b)*ch)+ec)
    for _ in range(90):
        m=(lo+hi)/2
        if v(m)<=1e-9: lo=m
        else: hi=m
    return (lo+hi)/2

print("BASELINE  ci=.30 ch=.05 tpr=.70 fpr=.25 cost=.02")
print(f"  break-even prior = {breakeven_prior(.30,.05,.70,.25,.02):.3f}")
print(f"  separation floor = {sep_threshold(.20,.30,.05,.02):.3f}\n")

print("SENSITIVITY OF THE BELIEF THRESHOLD")
scen=[("harm ratio 3:1 (base)",.30,.05),("harm ratio 6:1",.30,.025),
      ("harm ratio 2:1",.20,.10),("harm ratio 10:1",.40,.02),
      ("low stakes overall",.10,.02)]
for nm,ci,ch in scen:
    print(f"  {nm:<24} -> {breakeven_prior(ci,ch,.70,.25,.02):.3f}")

print("\nSENSITIVITY TO STUDY QUALITY")
for nm,t,f in [("strong study .80/.15",.80,.15),("base .70/.25",.70,.25),
               ("weak study .60/.35",.60,.35)]:
    print(f"  {nm:<24} -> {breakeven_prior(.30,.05,t,f,.02):.3f}")

print("\nSENSITIVITY TO STUDY COST")
for ec in [0.005,0.02,0.05,0.10]:
    print(f"  cost={ec:<5} -> {breakeven_prior(.30,.05,.70,.25,ec):.3f}")

print("\nSEPARATION FLOOR across priors")
for pr in [0.10,0.15,0.20,0.35,0.50]:
    print(f"  prior={pr:.2f} -> {sep_threshold(pr,.30,.05,.02):.3f}")

# Analytic check: the belief threshold is driven by the harm ratio ch/ci
print("\nANALYTIC: indifference point where p*ci == (1-p)*ch  ->  p = ch/(ci+ch)")
for ci,ch in [(.30,.05),(.30,.025),(.20,.10),(.40,.02)]:
    print(f"  ci={ci}, ch={ch} -> p*={ch/(ci+ch):.3f}")
